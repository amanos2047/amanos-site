
function speak() {
  const msg = new SpeechSynthesisUtterance("आपका AmanOS सुन रहा है, कमलेश्वर जी!");
  speechSynthesis.speak(msg);
}
